from tkinter import *
from random import *
window=Tk()
window.geometry('500x500')


gameover=[]
image=PhotoImage(file='game_over.png')
gameover.append(image)



num=randrange(1,50)
frame1=Frame(window)
frame1.grid(column=0,row=0)
suits=["hearts",'clubs','diamonds','spades']
faces=['jack','queen',"king"]
total_cards=[]
for card in suits:
    for i in range(1,11):
        add="cards/{}_of_{}.png".format(i,card)
        image=PhotoImage(file=add)
        total_cards.append((i,image))
    for i in range(0,3):
        add="cards/{}_of_{}.png".format(faces[i],card)
        image=PhotoImage(file=add)
        j=11+i
        total_cards.append((j,image))
# print(total_cards)
def close():

    window.destroy()

def change():
    num=randrange(0,51)
    # label1 = Label(frame1, image=total_cards[num][1])
    card=total_cards[num][1]
    label1 = Label(frame1, image=card)
    label1.grid(column=0, row=0)
    score.append(total_cards[num][0])
    total_score = 0
    for i in score:
        total_score = total_score + i
    frame11=LabelFrame(frame1,text='  Score  ')
    frame11.grid(column=2, row=0, sticky='w')
    scorel = Label(frame11, text=str(total_score))
    scorel.grid(column=0, row=0, sticky='')
    turns=len(score)
    frame12=LabelFrame(frame1,text="   Turns  ")
    frame12.grid(column=2, row=1, sticky='')
    scorel = Label(frame12, text=str(turns))
    scorel.grid(column=0, row=0, sticky='')
    if turns==5:
        image=gameover[0]
        Turn_over=Label(window,image=image)
        Turn_over.grid(row=0,column=0)
        final_score=Label(window,foreground='red',height=2,text="Final Score is :-- {}".format(total_score),font=('BatmanForeverAlternate', '15'))
        final_score.grid(row=1,column=0)
        exit=Button(window,text="E-X-I-T",width=20,background='red',font=('BatmanForeverAlternate', '15'),borderwidth=2,command=close)
        exit.grid(column=0,row=2,sticky='en',)




score=[]
label1=Label(frame1,image=total_cards[num][1])
label1.grid(column=0,row=0)
button=Button(frame1,text="Change", command=change)
button.grid(column=1,row=1,sticky='ne')
total_score=0
window.mainloop()
